# Casino Review Hub React Export

This project was reconstructed from a UI Bakery custom React app export into a standard Vite + React + TypeScript app.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

Upload the contents of `dist/` to your hosting.

If your hosting does not automatically route all paths to `index.html`, configure a SPA fallback so routes like `/casinos` and `/hotels` load correctly.
