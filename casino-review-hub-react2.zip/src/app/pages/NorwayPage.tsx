import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import StarRating from '@/app/components/StarRating';
import { norwayCasinos } from '@/app/data/norway';
import { CheckCircle, Shield, ExternalLink, AlertCircle } from 'lucide-react';

function useNavigateTo(path: string) {
  useEffect(() => {
    window.history.replaceState(null, '', path);
    window.dispatchEvent(new PopStateEvent('popstate'));
  }, [path]);
}

function RedirectToHome() {
  useNavigateTo('/');
  return null;
}

export default function NorwayPage() {
  const [checked, setChecked] = useState(false);
  const [allowed, setAllowed] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setAllowed(params.get('utm_campaign') === 'siteno');
    setChecked(true);
  }, []);

  if (!checked) return null;
  if (!allowed) return <RedirectToHome />;

  return (
    <div className="min-h-screen bg-white">
      {/* Norway Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-red-700 via-red-600 to-blue-900 text-white py-20 px-4">
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: 'repeating-linear-gradient(0deg, #fff 0, #fff 2px, transparent 0, transparent 30px), repeating-linear-gradient(90deg, #fff 0, #fff 2px, transparent 0, transparent 30px)', backgroundSize: '30px 30px' }}
        />
        <div className="relative max-w-4xl mx-auto text-center">
          <div className="text-5xl mb-4">🇳🇴</div>
          <Badge className="mb-5 bg-white/20 text-white border-white/30 text-sm px-4 py-1">
            Norges Beste Casinoer 2026
          </Badge>
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 leading-tight">
            Norges Beste<br />
            <span className="text-yellow-300">Online Casinoer</span>
          </h1>
          <p className="text-lg text-red-100 mb-3 max-w-2xl mx-auto">
            Vi har testet og rangert de beste casinoene for norske spillere i 2026.
          </p>
          <p className="text-base text-red-200 mb-8 max-w-2xl mx-auto">
            <em>Find Norway's top-rated online casinos with NOK bonuses, Norwegian support, and BankID login — all reviewed by our expert team.</em>
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href={norwayCasinos[0].url} target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="bg-yellow-400 hover:bg-yellow-300 text-gray-900 font-bold px-8">
                🎰 Spill Nå — {norwayCasinos[0].name}
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <div className="bg-blue-900 text-white py-4 px-4">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          {[
            { label: 'Testede Casinoer', value: '8+' },
            { label: 'Norske Betalingsmetoder', value: 'BankID, Vipps' },
            { label: 'Oppdatert', value: 'Mars 2026' },
            { label: 'Lisensiering', value: 'MGA / UKGC' },
          ].map((s) => (
            <div key={s.label}>
              <div className="text-xl font-bold text-yellow-300">{s.value}</div>
              <div className="text-xs text-blue-200 mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Casino Cards */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12">
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">🏆 Topp Rangerte Casinoer</h2>
        <p className="text-muted-foreground mb-8">Rangert etter sikkerhet, spillutvalg, bonusvilkår og norsk brukervennlighet.</p>

        <div className="space-y-5">
          {norwayCasinos.map((casino, idx) => (
            <Card key={casino.id} className={`border overflow-hidden hover:shadow-lg transition-shadow ${idx === 0 ? 'border-yellow-300 ring-2 ring-yellow-200' : 'border-border'}`}>
              <CardContent className="p-0">
                <div className="flex flex-col sm:flex-row">
                  <div className={`${casino.color} w-full sm:w-32 flex-shrink-0 flex flex-col items-center justify-center py-6 px-3 gap-1`}>
                    <span className="text-white text-3xl font-bold opacity-80">{casino.name.charAt(0)}</span>
                    <span className="text-white text-xs opacity-60">#{idx + 1}</span>
                    {idx === 0 && <span className="text-yellow-300 text-xs font-bold mt-1">⭐ #1</span>}
                  </div>
                  <div className="flex-1 p-5">
                    <div className="flex items-start justify-between gap-2 flex-wrap mb-1">
                      <h3 className="font-bold text-lg text-gray-900">{casino.name}</h3>
                      <div className="flex gap-2 flex-wrap">
                        <Badge className="bg-blue-50 text-blue-700 border-blue-200 text-xs">{casino.badge}</Badge>
                        <Badge variant="outline" className="text-xs text-gray-500">{casino.license}</Badge>
                      </div>
                    </div>
                    <StarRating rating={casino.rating} />
                    <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{casino.description}</p>
                    <ul className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-1">
                      {casino.features.map((f) => (
                        <li key={f} className="flex items-center gap-1.5 text-xs text-gray-700">
                          <CheckCircle className="w-3.5 h-3.5 text-green-500 flex-shrink-0" /> {f}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-4 flex items-center justify-between gap-3 flex-wrap">
                      <div className="bg-green-50 border border-green-200 rounded-lg px-3 py-1.5">
                        <span className="text-xs text-green-600 font-medium">💰 Bonus: </span>
                        <span className="text-sm font-bold text-green-800">{casino.bonusNOK}</span>
                      </div>
                      <a href={casino.url} target="_blank" rel="noopener noreferrer">
                        <Button className="bg-red-600 hover:bg-red-700 text-white font-semibold">
                          Spill Nå →
                        </Button>
                      </a>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Norwegian Bonuses Section */}
      <section className="bg-blue-50 py-12 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">🎁 Eksklusive Bonuser for Norske Spillere</h2>
          <p className="text-muted-foreground mb-6">Alle bonuser er tilgjengelige i norske kroner (NOK) og kan aktiveres umiddelbart.</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {norwayCasinos.slice(0, 6).map((casino) => (
              <div key={casino.id} className="bg-white border border-border rounded-xl p-4 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-gray-900 text-sm">{casino.name}</span>
                  <Badge className="bg-yellow-50 text-yellow-700 border-yellow-200 text-xs">NOK</Badge>
                </div>
                <p className="text-base font-bold text-red-700 mb-1">{casino.bonusNOK}</p>
                <StarRating rating={casino.rating} size="sm" />
                <a href={casino.url} target="_blank" rel="noopener noreferrer">
                  <Button size="sm" className="mt-3 w-full bg-blue-700 hover:bg-blue-800 text-white text-xs">
                    Hent Bonus →
                  </Button>
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Norway Gambling Regulations */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 py-10">
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 flex gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-bold text-yellow-900 mb-2">Om Pengespill i Norge</h3>
            <p className="text-sm text-yellow-800 leading-relaxed mb-3">
              I Norge er pengespill regulert av Lotteri- og stiftelsestilsynet. Norsk Tipping og Norsk Rikstoto er de eneste lovlige norske tilbyderne. Utenlandske casinoer er ikke lisensiert i Norge, men er ikke eksplisitt ulovlig å spille hos for privatpersoner. Vi anbefaler alltid ansvarlig spill.
            </p>
            <p className="text-sm text-yellow-800 leading-relaxed">
              <strong>Hjelpetelefonen for spillavhengighet: 800 800 40</strong> (gratis, åpent hverdager 09–21)
            </p>
            <div className="flex gap-4 mt-3 flex-wrap">
              <a href="https://www.norskTipping.no/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-xs text-yellow-700 hover:text-yellow-900">
                <ExternalLink className="w-3 h-3" /> Norsk Tipping
              </a>
              <a href="https://lottstift.no/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-xs text-yellow-700 hover:text-yellow-900">
                <ExternalLink className="w-3 h-3" /> Lotteri- og stiftelsestilsynet
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Norway Footer */}
      <footer className="bg-gray-900 text-gray-400 text-center py-6 px-4 text-xs">
        <div className="flex items-center justify-center gap-2 mb-2 text-white font-bold">
          <Shield className="w-4 h-4 text-green-400" />
          18+ | Spill Ansvarlig | Bare for underholdning
        </div>
        <p>© {new Date().getFullYear()} CasinoNorway. Inneholder affiliatelenker. Vi kan motta provisjon uten kostnad for deg.</p>
      </footer>
    </div>
  );
}
