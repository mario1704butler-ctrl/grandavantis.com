'use client';

import '@/index.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from '@/app/components/Navbar';
import Footer from '@/app/components/Footer';
import HomePage from '@/app/pages/HomePage';
import CasinosPage from '@/app/pages/CasinosPage';
import HotelsPage from '@/app/pages/HotelsPage';
import BonusesPage from '@/app/pages/BonusesPage';
import AboutPage from '@/app/pages/AboutPage';
import NorwayPage from '@/app/pages/NorwayPage';

function MainLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Norway hidden page — no Navbar/Footer */}
        <Route path="/norway" element={<NorwayPage />} />

        {/* Main site */}
        <Route path="/" element={<MainLayout><HomePage /></MainLayout>} />
        <Route path="/casinos" element={<MainLayout><CasinosPage /></MainLayout>} />
        <Route path="/hotels" element={<MainLayout><HotelsPage /></MainLayout>} />
        <Route path="/bonuses" element={<MainLayout><BonusesPage /></MainLayout>} />
        <Route path="/about" element={<MainLayout><AboutPage /></MainLayout>} />

        {/* Fallback */}
        <Route path="*" element={<MainLayout><HomePage /></MainLayout>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
